<?php

namespace App\Http\Controllers;

use App\Exports\InvoiceExport;
use App\Exports\InvoiceCreditNotesExport;
use App\Exports\InvoiceDebitNotesExport;
use App\Models\BankAccount;
use App\Models\CreditNote;
use App\Models\Customer;
use App\Models\CustomField;
use App\Models\Invoice;
use App\Models\InvoiceBankTransfer;
use App\Models\Proforma;
use App\Models\Purchase;
use App\Models\Quotation;
use App\Models\InvoicePayment;
use App\Models\InvoiceProduct;
use App\Models\Plan;
use App\Models\ProductIdentifier;
use App\Models\ProductService;
use App\Models\ProductServiceCategory;
use App\Models\StockReport;
use App\Models\Transaction;
use App\Models\User;
use App\Models\Utility;
use App\Models\TransactionLines;
use App\Services\DocumentVoidService;
use App\Services\Accounting\DocumentLedgerService;
use App\Services\Accounting\CustomerCreditLimitService;
use App\Support\SalesPurchaseNotifier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use App\Support\LoggedMail;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\CustomerBillingAddress;
use App\Models\CustomerShippingAddress;
use App\Services\InvoiceSaleDeductionService;

class InvoiceController extends Controller
{
    public function __construct()
    {
    }

    public function index(Request $request)
    {
        if (\Auth::user()->can('manage invoice')) {
            $customer = Customer::where('created_by', '=', \Auth::user()->creatorId())->get()->pluck('name', 'id');
            $customer->prepend('Select Customer', '');
            $status = Invoice::$statues;
            $query = Invoice::where('created_by', '=', \Auth::user()->creatorId());

            if (!empty($request->customer)) {
                $query->where('customer_id', '=', $request->customer);
            }
            if (count(explode('to', $request->issue_date)) > 1) {
                $date_range = explode(' to ', $request->issue_date);
                $query->whereBetween('issue_date', $date_range);
            } elseif (!empty($request->issue_date)) {
                $date_range = [$request->issue_date, $request->issue_date];
                $query->whereBetween('issue_date', $date_range);
            }
            if ($request->status != null) {
                $query->where('status', '=', $request->status);
            }
            if ($request->filled('search')) {
                $term = trim((string) $request->search);
                $query->where(function ($q) use ($term) {
                    $q->where('invoice_id', 'like', '%' . $term . '%')
                        ->orWhere('ref_number', 'like', '%' . $term . '%')
                        ->orWhereHas('items', function ($iq) use ($term) {
                            $iq->where('identifiers', 'like', '%' . $term . '%');
                        });
                });
            }
            $invoices = $query->get();

            return view('invoice.index', compact('invoices', 'customer', 'status'));
        } else {
            return redirect()->back()->with('error', __('Permission Denied.'));
        }
    }

    public function create($customerId = 0)
    {
        if (\Auth::user()->can('create invoice')) {
            $customFields = CustomField::where('created_by', '=', \Auth::user()->creatorId())->where('module', '=', 'invoice')->get();
            $invoice_number = \Auth::user()->invoiceNumberFormat($this->invoiceNumber());
            $customers = Customer::where('created_by', \Auth::user()->creatorId())->get()->pluck('name', 'id');
            $customers->prepend('Select Customer', '');
            $category = ProductServiceCategory::where('created_by', \Auth::user()->creatorId())->where('type', 'income')->get()->pluck('name', 'id');
            $category->prepend('Select Category', '');
            $product_services = ProductService::where('created_by', \Auth::user()->creatorId())->get()->pluck('name', 'id');
            $product_services->prepend('--', '');

            return view('invoice.create', compact('customers', 'invoice_number', 'product_services', 'category', 'customFields', 'customerId'));
        } else {
            return response()->json(['error' => __('Permission denied.')], 401);
        }
    }

    public function customer(Request $request)
    {
        $customer = Customer::where('id', '=', $request->id)->first();
        return view('invoice.customer_detail', compact('customer'));
    }
    public function customer_addresses(Request $request)
    {
        $shipping_address = CustomerShippingAddress::where('customer_id', $request->id)->get();
        $billing_address = CustomerBillingAddress::where('customer_id', $request->id)->get();
        return response()->json(["shipping_address" => $shipping_address, "billing_address" => $billing_address]);
    }
    public function customer_address_detail(Request $request)
    {
        $shipping_address = CustomerShippingAddress::where('id', '=', $request->shipping_id)->first();
        $billing_address = CustomerBillingAddress::where('id', '=', $request->billing_id)->first();
        return view('invoice.specific_customer_details', compact('shipping_address', 'billing_address'));
    }

    public function product(Request $request)
    {
        $data['product'] = $product = ProductService::find($request->product_id);
        $data['unit'] = (!empty($product->unit)) ? $product->unit->name : '';
        $data['taxRate'] = $taxRate = !empty($product->tax_id) ? $product->taxRate($product->tax_id) : 0;
        $data['taxes'] = !empty($product->tax_id) ? $product->tax($product->tax_id) : 0;
        $salePrice = $product->sale_price;
        $quantity = 1;
        $taxPrice = ($taxRate / 100) * ($salePrice * $quantity);
        $data['totalAmount'] = ($salePrice * $quantity);
        $data['identifier_tracking'] = (bool) ($product->identifier_tracking ?? false);
        $data['identifier_type'] = $product->identifier_type ?? 'serial';
        $data['unit_type'] = $product->unit_type;
        $data['dimension_unit'] = $product->dimension_unit ?: ($product->unit->length_unit ?? 'cm');
        $data['dimension_mode'] = $product->unit->dimension_mode ?? null;
        $data['volumetric_divisor'] = $product->volumetric_divisor ?: ($product->unit->volumetric_divisor ?? null);
        $data['unit_length'] = $product->unit_length;
        $data['unit_width'] = $product->unit_width;
        $data['unit_height'] = $product->unit_height;
        $data['unit_area_sqm'] = $product->unit_area_sqm;
        $data['unit_volume_cbm'] = $product->unit_volume_cbm;

        $data = array_merge($data, $product->variantsForDocumentJson('sale_price'));
        $data = array_merge($data, \App\Services\ProductOptionService::productJsonExtras($product));

        return json_encode($data);
    }

    /**
     * In-stock Serial/MAC identifiers for invoice lines (optional: include identifiers already on this invoice line when editing).
     */
    public function productIdentifiers(Request $request)
    {
        if (! \Auth::user()->can('create invoice') && ! \Auth::user()->can('edit invoice')) {
            return response()->json(['error' => __('Permission denied.')], 403);
        }

        $request->validate([
            'product_id' => 'required|integer',
            'invoice_id' => 'nullable|integer',
            'invoice_product_id' => 'nullable|integer',
        ]);

        $creatorId = \Auth::user()->creatorId();
        $product = ProductService::where('id', $request->product_id)->where('created_by', $creatorId)->first();

        if (! $product || ! ($product->identifier_tracking ?? false)) {
            return response()->json(['identifiers' => []]);
        }

        $invoiceId = $request->filled('invoice_id') ? (int) $request->invoice_id : null;
        $invoiceProductId = $request->filled('invoice_product_id') ? (int) $request->invoice_product_id : null;

        if ($invoiceId) {
            $inv = Invoice::where('id', $invoiceId)->where('created_by', $creatorId)->first();
            if (! $inv) {
                return response()->json(['error' => __('Permission denied.')], 403);
            }
        }

        if ($invoiceId && $invoiceProductId) {
            $line = InvoiceProduct::where('id', $invoiceProductId)->first();
            if (! $line || (int) $line->invoice_id !== $invoiceId) {
                return response()->json(['error' => __('Invalid line item.')], 422);
            }
            $invLine = Invoice::where('id', $invoiceId)->where('created_by', $creatorId)->first();
            if (! $invLine) {
                return response()->json(['error' => __('Permission denied.')], 403);
            }
        }

        $query = ProductIdentifier::query()
            ->where('created_by', $creatorId)
            ->where('product_id', $product->id)
            ->where(function ($q) use ($invoiceId, $invoiceProductId) {
                $q->where('status', 'in_stock');
                if ($invoiceId && $invoiceProductId) {
                    $q->orWhere(function ($q2) use ($invoiceId, $invoiceProductId) {
                        $q2->where('invoice_id', $invoiceId)
                            ->where('invoice_product_id', $invoiceProductId);
                    });
                }
            })
            ->orderBy('identifier_value');

        $identifiers = $query->get(['id', 'identifier_type', 'identifier_value', 'status'])->map(function ($r) {
            return [
                'id' => $r->id,
                'identifier_type' => $r->identifier_type,
                'identifier_value' => $r->identifier_value,
                'status' => $r->status,
            ];
        });

        return response()->json(['identifiers' => $identifiers]);
    }

    public function store(Request $request)
    {
        if (\Auth::user()->can('create invoice')) {
            $validator = \Validator::make(
                $request->all(), [
                    'customer_id' => 'required',
                    'issue_date' => 'required',
                    'due_date' => 'required',
                    'category_id' => 'required',
                    'items' => 'required',
                ]
            );
            if ($validator->fails()) {
                $messages = $validator->getMessageBag();
                return redirect()->back()->with('error', $messages->first());
            }

            $products = $request->items;
            foreach ($products as $p) {
                try {
                    InvoiceSaleDeductionService::validateTrackedIdentifiersForLine(
                        (int) $p['item'],
                        (float) $p['quantity'],
                        (int) \Auth::user()->creatorId(),
                        $p['identifiers'] ?? null
                    );
                } catch (\Throwable $e) {
                    return redirect()->back()->with('error', $e->getMessage())->withInput();
                }
            }

            try {
                $invoice = DB::transaction(function () use ($request, $products) {
                    $invoice = new Invoice();
                    $invoice->invoice_id = $this->invoiceNumber();
                    $invoice->customer_id = $request->customer_id;
                    $invoice->status = 0;
                    $invoice->issue_date = $request->issue_date;
                    $invoice->due_date = $request->due_date;
                    $invoice->category_id = $request->category_id;
                    $invoice->ref_number = $request->ref_number;
                    $invoice->client_po_number = $request->input('client_po_number');
                    $invoice->client_po_date = $request->input('client_po_date') ?: null;
                    $invoice->client_po_details = $request->input('client_po_details');
                    $invoice->quotation_reference = $request->input('quotation_reference');
                    $invoice->billing_address_id = $request->billing_address ?? null;
                    $invoice->shipping_address_id = $request->shipping_address ?? null;
                    $invoice->created_by = \Auth::user()->creatorId();
                    $creatorId = (int) \Auth::user()->creatorId();
                    $invoice->quotation_id = null;
                    $invoice->proforma_id = null;
                    if ($request->filled('source_proforma_id')) {
                        $pf = Proforma::where('id', (int) $request->input('source_proforma_id'))->where('created_by', $creatorId)->first();
                        if ($pf) {
                            $invoice->proforma_id = $pf->id;
                            if ($pf->quotation_id) {
                                $invoice->quotation_id = $pf->quotation_id;
                            }
                        }
                    }
                    if ($request->filled('source_quotation_id') && empty($invoice->quotation_id)) {
                        $q = Quotation::where('id', (int) $request->input('source_quotation_id'))->where('created_by', $creatorId)->first();
                        if ($q) {
                            $invoice->quotation_id = $q->id;
                        }
                    }
                    if ($request->filled('source_purchase_id')) {
                        $purchase = Purchase::where('id', (int) $request->input('source_purchase_id'))
                            ->where('created_by', $creatorId)
                            ->first();
                        if ($purchase) {
                            $invoice->purchase_id = $purchase->id;
                            if (empty($invoice->proforma_id) && ! empty($purchase->proforma_id)) {
                                $invoice->proforma_id = $purchase->proforma_id;
                            }
                            if (empty($invoice->quotation_id) && ! empty($purchase->quotation_id)) {
                                $invoice->quotation_id = $purchase->quotation_id;
                            }
                        }
                    }
                    if (empty($invoice->quotation_reference) && ! empty($invoice->quotation_id)) {
                        $q = Quotation::find($invoice->quotation_id);
                        if ($q) {
                            $invoice->quotation_reference = \Auth::user()->quotationNumberFormat($q->quotation_id);
                        }
                    }
                    $invoice->save();
                    CustomField::saveData($invoice, $request->input('customField'));

                    StockReport::where('type', '=', 'invoice')->where('type_id', '=', $invoice->id)->delete();

                    $settings = Utility::settings();
                    $timing = $settings['stock_deduction_timing'] ?? 'invoice';

                    for ($i = 0; $i < count($products); $i++) {
                        $invoiceProduct = new InvoiceProduct();
                        $invoiceProduct->invoice_id = $invoice->id;
                        $invoiceProduct->product_id = $products[$i]['item'];
                        $invoiceProduct->product_variant_id = ! empty($products[$i]['product_variant_id'])
                            ? (int) $products[$i]['product_variant_id']
                            : null;
                        $invoiceProduct->quantity = $products[$i]['quantity'];
                        $invoiceProduct->tax = $products[$i]['tax'];
                        $invoiceProduct->discount = $products[$i]['discount'];
                        $invoiceProduct->price = $products[$i]['price'];
                        $invoiceProduct->description = $products[$i]['description'];
                        $invoiceProduct->identifiers = $products[$i]['identifiers'] ?? null;
                        $invoiceProduct->measurement_json = $products[$i]['measurement_json'] ?? null;
                        $invoiceProduct->selected_options_json = ! empty($products[$i]['selected_options_json'])
                            ? (is_string($products[$i]['selected_options_json'])
                                ? $products[$i]['selected_options_json']
                                : json_encode($products[$i]['selected_options_json']))
                            : null;
                        $invoiceProduct->save();

                        if ($timing === 'invoice') {
                            InvoiceSaleDeductionService::deductLine(
                                (int) $invoiceProduct->product_id,
                                (float) $invoiceProduct->quantity,
                                (int) \Auth::user()->creatorId(),
                                (int) $invoice->id,
                                (int) $invoiceProduct->id,
                                (int) $invoice->customer_id,
                                \Auth::user()->invoiceNumberFormat($invoice->invoice_id),
                                $invoiceProduct->identifiers,
                                $invoiceProduct->selected_options_json
                            );
                        }
                    }

                    if ($timing === 'invoice' && empty($invoice->stock_deducted_at)) {
                        $invoice->stock_deducted_at = now();
                        $invoice->stock_deducted_via = 'invoice';
                        $invoice->save();
                    }

                    if ($request->filled('source_purchase_id') && ! empty($invoice->purchase_id)) {
                        Purchase::where('id', (int) $invoice->purchase_id)
                            ->where('created_by', $creatorId)
                            ->update([
                                'converted_invoice_id' => $invoice->id,
                                'is_invoice_converted' => 1,
                            ]);
                    }
                    if (! empty($invoice->proforma_id)) {
                        Proforma::where('id', (int) $invoice->proforma_id)
                            ->where('created_by', $creatorId)
                            ->update([
                                'converted_invoice_id' => $invoice->id,
                                'is_invoice_converted' => 1,
                            ]);
                    }
                    if (! empty($invoice->quotation_id)) {
                        Quotation::where('id', (int) $invoice->quotation_id)
                            ->where('created_by', $creatorId)
                            ->update([
                                'converted_invoice_id' => $invoice->id,
                            ]);
                    }

                    return $invoice->fresh();
                });
            } catch (\Throwable $e) {
                return redirect()->back()->with('error', $e->getMessage())->withInput();
            }

            $setting = Utility::settings(\Auth::user()->creatorId());
            $customer = Customer::find($request->customer_id);
            if ($customer) {
                $invoiceNotificationArr = [
                    'invoice_number' => \Auth::user()->invoiceNumberFormat($invoice->invoice_id),
                    'user_name' => \Auth::user()->name,
                    'invoice_issue_date' => $invoice->issue_date,
                    'invoice_due_date' => $invoice->due_date,
                    'customer_name' => $customer->name,
                ];
                if (isset($setting['invoice_notification']) && $setting['invoice_notification'] == 1) {
                    Utility::send_slack_msg('new_invoice', $invoiceNotificationArr);
                }
                if (isset($setting['telegram_invoice_notification']) && $setting['telegram_invoice_notification'] == 1) {
                    Utility::send_telegram_msg('new_invoice', $invoiceNotificationArr);
                }
                if (isset($setting['twilio_invoice_notification']) && $setting['twilio_invoice_notification'] == 1) {
                    Utility::send_twilio_msg($customer->contact, 'new_invoice', $invoiceNotificationArr);
                }
            }

            //webhook
            $module = 'New Invoice';
            $webhook = Utility::webhookSetting($module);
            if ($webhook) {
                $parameter = json_encode($invoice);
                $status = Utility::WebhookCall($webhook['url'], $parameter, $webhook['method']);
                if ($status == true) {
                    return redirect()->route('invoice.show', Crypt::encrypt($invoice->id))->with('success', __('Invoice successfully created.'));
                } else {
                    return redirect()->back()->with('error', __('Invoice successfully created, Webhook call failed.'));
                }
            }

            if ($request->filled('source_purchase_id')) {
                return redirect()->route('invoice.show', Crypt::encrypt($invoice->id))
                    ->with('success', __('Sales invoice created from purchase order. Send the invoice to post accounting entries.'));
            }

            if ($request->filled('source_proforma_id') || $request->filled('source_quotation_id')) {
                return redirect()->route('invoice.show', Crypt::encrypt($invoice->id))
                    ->with('success', __('Invoice successfully created.'));
            }

            return redirect()->route('invoice.index', $invoice->id)->with('success', __('Invoice successfully created.'));
        } else {
            return redirect()->back()->with('error', __('Permission denied.'));
        }
    }

    public function edit($ids)
    {
        if (\Auth::user()->can('edit invoice')) {
            try{
                $id = Crypt::decrypt($ids);
            } catch (\Exception $e){
                return redirect()->back()->with('error', __('Something went wrong.'));
            }
            $invoice = Invoice::find($id);
            $invoice_number = \Auth::user()->invoiceNumberFormat($invoice->invoice_id);
            $customers = Customer::where('created_by', \Auth::user()->creatorId())->get()->pluck('name', 'id');
            $category = ProductServiceCategory::where('created_by', \Auth::user()->creatorId())->where('type', 'income')->get()->pluck('name', 'id');
            $category->prepend('Select Category', '');
            $product_services = ProductService::where('created_by', \Auth::user()->creatorId())->get()->pluck('name', 'id');
            $invoice->customField = CustomField::getData($invoice, 'invoice');
            $customFields = CustomField::where('created_by', '=', \Auth::user()->creatorId())->where('module', '=', 'invoice')->get();
        
            $billing_addresses = CustomerBillingAddress::where("customer_id", $invoice->customer_id)
                ->get()
                ->pluck('name', 'id')
                ->prepend('Select Billing Address', '');
            
            $shipping_addresses = CustomerShippingAddress::where("customer_id", $invoice->customer_id)
                ->get()
                ->pluck('name', 'id')
                ->prepend('Select Shipping Address', '');


            return view('invoice.edit', compact('customers', 'product_services', 'invoice', 'invoice_number', 'category', 'customFields', 'billing_addresses', 'shipping_addresses'));
        } else {
            return response()->json(['error' => __('Permission denied.')], 401);
        }
    }

    public function update(Request $request, Invoice $invoice)
    {

        if (\Auth::user()->can('edit invoice')) {
            if ($invoice->created_by == \Auth::user()->creatorId()) {
                $validator = \Validator::make(
                    $request->all(),
                    [
                        'customer_id' => 'required',
                        'issue_date' => 'required',
                        'due_date' => 'required',
                        'category_id' => 'required',
                        'items' => 'required',
                    ]
                );
                if ($validator->fails()) {
                    $messages = $validator->getMessageBag();

                    return redirect()->route('invoice.index')->with('error', $messages->first());
                }
                Utility::updateUserBalance('customer', $request->customer_id, $invoice->getTotal(), 'debit');

                $invoice->customer_id = $request->customer_id;
                $invoice->issue_date = $request->issue_date;
                $invoice->due_date = $request->due_date;
                $invoice->ref_number = $request->ref_number;
                $invoice->client_po_number = $request->input('client_po_number');
                $invoice->client_po_date = $request->input('client_po_date') ?: null;
                $invoice->client_po_details = $request->input('client_po_details');
                $invoice->quotation_reference = $request->input('quotation_reference');
                //                $invoice->discount_apply = isset($request->discount_apply) ? 1 : 0;
                $invoice->category_id = $request->category_id;
                $invoice->billing_address_id = $request->billing_address ?? $invoice->billing_address_id;
                $invoice->shipping_address_id = $request->shipping_address ?? $invoice->shipping_address_id;
                $invoice->save();

                Utility::starting_number($invoice->invoice_id + 1, 'invoice');
                CustomField::saveData($invoice, $request->customField);
                $products = $request->items;
                $updatePrice = 0;

                for ($i = 0; $i < count($products); $i++) {
                    $invoiceProduct = InvoiceProduct::find($products[$i]['id']);


                    if ($invoiceProduct == null) {
                        $invoiceProduct = new InvoiceProduct();
                        $invoiceProduct->invoice_id = $invoice->id;

                        Utility::total_quantity('minus', $products[$i]['quantity'], $products[$i]['item']);

                        // $updatePrice = ($products[$i]['price'] * $products[$i]['quantity']) + ($products[$i]['itemTaxPrice']) - ($products[$i]['discount']);

                        // Utility::updateUserBalance('customer', $request->customer_id, $invoice->getTotal(), 'credit');
                    } else {
                        // Utility::updateUserBalance('customer', $request->customer_id, $invoice->getTotal(), 'credit');
                        Utility::total_quantity('plus', $invoiceProduct->quantity, $invoiceProduct->product_id);

                    }

                    $updatePrice += ($products[$i]['price'] * $products[$i]['quantity']) + ($products[$i]['itemTaxPrice']) - ($products[$i]['discount']);




                    if (isset($products[$i]['item'])) {
                        $invoiceProduct->product_id = $products[$i]['item'];
                    }

                    $invoiceProduct->quantity = $products[$i]['quantity'];
                    $invoiceProduct->tax = $products[$i]['tax'];
                    $invoiceProduct->discount = $products[$i]['discount'];
                    $invoiceProduct->price = $products[$i]['price'];
                    $invoiceProduct->description = $products[$i]['description'];
                    $invoiceProduct->product_variant_id = ! empty($products[$i]['product_variant_id'])
                        ? (int) $products[$i]['product_variant_id']
                        : null;
                    $invoiceProduct->identifiers = $products[$i]['identifiers'] ?? null;
                    $invoiceProduct->measurement_json = $products[$i]['measurement_json'] ?? null;

                    try {
                        InvoiceSaleDeductionService::validateTrackedIdentifiersForLine(
                            (int) $invoiceProduct->product_id,
                            (float) $invoiceProduct->quantity,
                            (int) \Auth::user()->creatorId(),
                            $invoiceProduct->identifiers
                        );
                    } catch (\Throwable $e) {
                        return redirect()->back()->with('error', $e->getMessage())->withInput();
                    }

                    $invoiceProduct->save();

                    if ($products[$i]['id'] > 0) {
                        Utility::total_quantity('minus', $products[$i]['quantity'], $invoiceProduct->product_id);
                    }

                    //Product Stock Report
                    $type = 'invoice';
                    $type_id = $invoice->id;
                    StockReport::where('type', '=', 'invoice')->where('type_id', '=', $invoice->id)->delete();
                    $idSuffix = InvoiceSaleDeductionService::formatIdentifiersNote($products[$i]['identifiers'] ?? null);
                    $description = $products[$i]['quantity'] . '  ' . __(' quantity sold in invoice') . ' ' . \Auth::user()->invoiceNumberFormat($invoice->invoice_id) . $idSuffix;
                    if (empty($products[$i]['id'])) {
                        Utility::addProductStock($products[$i]['item'], $products[$i]['quantity'], $type, $description, $type_id);
                    }

                }

                Utility::updateUserBalance('customer', $request->customer_id, $updatePrice, 'credit');

                TransactionLines::where('reference_id',$invoice->id)->where('reference','Invoice')->delete();
                TransactionLines::where('reference_id',$invoice->id)->where('reference','Invoice Receivable')->delete();

                $invoice_products = InvoiceProduct::where('invoice_id', $invoice->id)->get();
                foreach ($invoice_products as $invoice_product) {
                    $product = ProductService::find($invoice_product->product_id);
                    $totalTaxPrice = 0;
                    if($invoice_product->tax != null){
                        $taxes = \App\Models\Utility::tax($invoice_product->tax);
                        foreach ($taxes as $tax) {
                            $taxPrice = \App\Models\Utility::taxRate($tax->rate, $invoice_product->price, $invoice_product->quantity, $invoice_product->discount);
                            $totalTaxPrice += $taxPrice;
                        }
                    }

                    $itemAmount = ($invoice_product->price * $invoice_product->quantity) - ($invoice_product->discount) + $totalTaxPrice;

                    $data = [
                        'account_id' => $product->sale_chartaccount_id,
                        'transaction_type' => 'Credit',
                        'transaction_amount' => $itemAmount,
                        'reference' => 'Invoice',
                        'reference_id' => $invoice->id,
                        'reference_sub_id' => $product->id,
                        'date' => $invoice->issue_date,
                    ];
                    Utility::addTransactionLines($data , 'edit');
                }

                app(DocumentLedgerService::class)->balanceDocumentLines(
                    (int) \Auth::user()->creatorId(),
                    (int) $invoice->id,
                    ['Invoice'],
                    'receivable',
                    'Invoice Receivable',
                    (string) $invoice->issue_date
                );

                return redirect()->route('invoice.index')->with('success', __('Invoice successfully updated.'));
            } else {
                return redirect()->back()->with('error', __('Permission denied.'));
            }
        } else {
            return redirect()->back()->with('error', __('Permission denied.'));
        }
    }

    public function invoiceNumber()
    {
        $latest = Invoice::where('created_by', '=', \Auth::user()->creatorId())->latest()->first();
        if (!$latest) {
            return 1;
        }

        return $latest->invoice_id + 1;
    }

    public function show($ids)
    {
       
        if (\Auth::user()->can('show invoice')) {
            try {
                $id = Crypt::decrypt($ids);
            } catch (\Throwable $th) {
                return redirect()->back()->with('error', __('Invoice Not Found.'));
            }
            $id = Crypt::decrypt($ids);
            $invoice = Invoice::with(['creditNote','payments.bankAccount','items.product.unit', 'shipping_address', 'billing_address', 'pos.branch', 'pos.table', 'pos.shift', 'deliveryNote.roadManifest', 'sourceQuotation', 'sourceProforma'])->find($id);

            if (!empty($invoice->created_by) == \Auth::user()->creatorId()) {
                $invoicePayment = InvoicePayment::where('invoice_id', $invoice->id)->first();

                $customer = $invoice->customer;
                $iteams = $invoice->items;
                $user = \Auth::user();

                // start for storage limit note
                $invoice_user = User::find($invoice->created_by);
                $user_plan = Plan::getPlan($invoice_user->plan);
                // end for storage limit note

                $invoice->customField = CustomField::getData($invoice, 'invoice');
                $customFields = CustomField::where('created_by', '=', \Auth::user()->creatorId())->where('module', '=', 'invoice')->get();

                $creditnote = CreditNote::where('invoice',$invoice->id)->where('is_debit', 0)->first();

                return view('invoice.view', compact('invoice', 'customer', 'iteams', 'invoicePayment', 'customFields', 'user', 'invoice_user', 'user_plan' , 'creditnote'));
            } else {
                return redirect()->back()->with('error', __('Permission denied.'));
            }
        } else {
            return redirect()->back()->with('error', __('Permission denied.'));
        }
    }

    public function destroy(Invoice $invoice, Request $request)
    {
        if (\Auth::user()->can('delete invoice')) {
            if ($invoice->created_by == \Auth::user()->creatorId()) {
                try {
                    DocumentVoidService::voidInvoice($invoice, [
                        'reason' => $request->input('void_reason'),
                        'warehouse_id' => $request->input('warehouse_id'),
                        'create_credit_note' => $request->boolean('create_credit_note'),
                        'stock_mode' => $request->input('stock_mode'),
                        'accounting_mode' => $request->input('accounting_mode'),
                    ]);
                } catch (\Throwable $e) {
                    return redirect()->back()->with('error', $e->getMessage());
                }

                return redirect()->route('invoice.index')->with('success', __('Invoice cancelled successfully.'));
            } else {
                return redirect()->back()->with('error', __('Permission denied.'));
            }
        } else {
            return redirect()->back()->with('error', __('Permission denied.'));
        }
    }

    public function productDestroy(Request $request)
    {

        if (\Auth::user()->can('delete invoice product')) {
            $invoiceProduct = InvoiceProduct::find($request->id);

            if($invoiceProduct)
            {
                $invoice = Invoice::find($invoiceProduct->invoice_id);
                $productService = ProductService::find($invoiceProduct->product_id);

                Utility::updateUserBalance('customer', $invoice->customer_id, $request->amount, 'debit');

                TransactionLines::where('reference_sub_id',$productService->id)->where('reference','Invoice')->delete();

                InvoiceProduct::where('id', '=', $request->id)->delete();
                return response()->json(['status' => true, 'message' => __('Invoice product successfully deleted.')]);
            } else {
                return response()->json(['status' => false, 'message' => __('Invoice product not found!')]);
            }
        } else {
            return response()->json(['status' => false, 'message' => __('Permission denied.')]);
        }
    }

    public function customerInvoice(Request $request)
    {
        if (\Auth::user()->can('manage customer invoice')) {

            $status = Invoice::$statues;
            $query = Invoice::where('customer_id', '=', \Auth::user()->id)->where('status', '!=', '0')->where('created_by', \Auth::user()->creatorId());

            if (!empty($request->issue_date)) {
                $date_range = explode(' - ', $request->issue_date);
                $query->whereBetween('issue_date', $date_range);
            }

            if (!empty($request->status)) {
                $query->where('status', '=', $request->status);
            }
            if ($request->filled('search')) {
                $term = trim((string) $request->search);
                $query->where(function ($q) use ($term) {
                    $q->where('invoice_id', 'like', '%' . $term . '%')
                        ->orWhere('ref_number', 'like', '%' . $term . '%')
                        ->orWhereHas('items', function ($iq) use ($term) {
                            $iq->where('identifiers', 'like', '%' . $term . '%');
                        });
                });
            }
            $invoices = $query->get();

            $customer = collect(['' => __('Select Customer')]);

            return view('invoice.index', compact('invoices', 'customer', 'status'));
        } else {
            return redirect()->back()->with('error', __('Permission Denied.'));
        }
    }

    public function customerInvoiceShow($id)
    {

        $invoice = Invoice::with('payments.bankAccount')->find($id);

        $user = User::where('id', $invoice->created_by)->first();
        if ($invoice->created_by == $user->creatorId()) {
            $customer = $invoice->customer;
            $iteams = $invoice->items;

            if ($user->type == 'super admin') {
                return view('invoice.view', compact('invoice', 'customer', 'iteams', 'user'));
            } elseif ($user->type == 'company') {
                return view('invoice.customer_invoice', compact('invoice', 'customer', 'iteams', 'user'));
            }
        } else {
            return redirect()->back()->with('error', __('Permission denied.'));
        }
    }

    public function sent($id)
    {
        if (! \Auth::user()->can('send invoice')) {
            return redirect()->back()->with('error', __('Permission denied.'));
        }

        $invoice = Invoice::where('id', $id)->where('created_by', \Auth::user()->creatorId())->first();
        if (! $invoice) {
            return redirect()->back()->with('error', __('Invoice not found'));
        }

        if ((int) $invoice->status !== Invoice::STATUS_DRAFT) {
            return redirect()->back()->with('error', __('Only draft invoices can be sent.'));
        }

        $customer = Customer::where('id', $invoice->customer_id)->first();
        if (! $customer) {
            return redirect()->back()->with('error', __('Customer not found.'));
        }

        $creditCheck = app(CustomerCreditLimitService::class)->evaluate(
            $customer,
            (float) $invoice->getTotal(),
            (int) $invoice->id
        );

        if ($creditCheck['exceeded']) {
            $labels = app(CustomerCreditLimitService::class)->reasonLabels($creditCheck);
            $invoice->status = Invoice::STATUS_PENDING_AUTHORIZATION;
            $invoice->credit_hold_reasons = implode(' | ', $labels);
            $invoice->send_date = null;
            $invoice->authorized_by = null;
            $invoice->authorized_at = null;
            $invoice->save();

            return redirect()->back()->with(
                'warning',
                __('Invoice saved but needs authorization before release to customer account.') . ' ' . implode(' ', $labels)
            );
        }

        $this->releaseInvoiceToAccount($invoice, $customer);

        return redirect()->back()->with('success', __('Invoice successfully sent.'));
    }

    public function authorizeInvoice($id)
    {
        if (! \Auth::user()->can('authorize invoice')) {
            return redirect()->back()->with('error', __('Permission denied.'));
        }

        $invoice = Invoice::where('id', $id)->where('created_by', \Auth::user()->creatorId())->first();
        if (! $invoice) {
            return redirect()->back()->with('error', __('Invoice not found'));
        }

        if ((int) $invoice->status !== Invoice::STATUS_PENDING_AUTHORIZATION) {
            return redirect()->back()->with('error', __('Only invoices pending authorization can be authorized.'));
        }

        $customer = Customer::where('id', $invoice->customer_id)->first();
        if (! $customer) {
            return redirect()->back()->with('error', __('Customer not found.'));
        }

        $this->releaseInvoiceToAccount($invoice, $customer, true);

        return redirect()->back()->with('success', __('Invoice authorized and released to customer account.'));
    }

    public function rejectAuthorization($id)
    {
        if (! \Auth::user()->can('reject invoice authorization')) {
            return redirect()->back()->with('error', __('Permission denied.'));
        }

        $invoice = Invoice::where('id', $id)->where('created_by', \Auth::user()->creatorId())->first();
        if (! $invoice) {
            return redirect()->back()->with('error', __('Invoice not found'));
        }

        if ((int) $invoice->status !== Invoice::STATUS_PENDING_AUTHORIZATION) {
            return redirect()->back()->with('error', __('Only invoices pending authorization can be rejected.'));
        }

        $invoice->status = Invoice::STATUS_DRAFT;
        $invoice->credit_hold_reasons = null;
        $invoice->authorized_by = null;
        $invoice->authorized_at = null;
        $invoice->send_date = null;
        $invoice->save();

        return redirect()->back()->with('success', __('Invoice authorization rejected. Invoice returned to draft.'));
    }

    /**
     * Post invoice to GL / customer account and mark as Sent.
     */
    protected function releaseInvoiceToAccount(Invoice $invoice, Customer $customer, bool $fromAuthorization = false): void
    {
        $invoice->send_date = date('Y-m-d');
        $invoice->status = Invoice::STATUS_SENT;
        if ($fromAuthorization) {
            $invoice->authorized_by = \Auth::id();
            $invoice->authorized_at = now();
        }
        $invoice->save();

        $alreadyPosted = TransactionLines::where('reference_id', $invoice->id)
            ->whereIn('reference', ['Invoice', 'Invoice Receivable'])
            ->exists();

        if (! $alreadyPosted) {
            $invoice_products = InvoiceProduct::where('invoice_id', $invoice->id)->get();
            foreach ($invoice_products as $invoice_product) {
                $product = ProductService::find($invoice_product->product_id);
                if (! $product) {
                    continue;
                }
                $totalTaxPrice = 0;
                if ($invoice_product->tax != null) {
                    $taxes = \App\Models\Utility::tax($invoice_product->tax);
                    foreach ($taxes as $tax) {
                        $taxPrice = \App\Models\Utility::taxRate($tax->rate, $invoice_product->price, $invoice_product->quantity, $invoice_product->discount);
                        $totalTaxPrice += $taxPrice;
                    }
                }

                $itemAmount = ($invoice_product->price * $invoice_product->quantity) - ($invoice_product->discount) + $totalTaxPrice;

                $data = [
                    'account_id' => $product->sale_chartaccount_id,
                    'transaction_type' => 'Credit',
                    'transaction_amount' => $itemAmount,
                    'reference' => 'Invoice',
                    'reference_id' => $invoice->id,
                    'reference_sub_id' => $product->id,
                    'date' => $invoice->issue_date,
                ];
                Utility::addTransactionLines($data, 'create');
            }

            app(DocumentLedgerService::class)->balanceDocumentLines(
                (int) \Auth::user()->creatorId(),
                (int) $invoice->id,
                ['Invoice'],
                'receivable',
                'Invoice Receivable',
                (string) $invoice->issue_date
            );
        }

        $setings = Utility::settings();
        if (($setings['customer_invoice_sent'] ?? 0) == 1) {
            $invoice->name = ! empty($customer) ? $customer->name : '';
            $invoice->invoice = \Auth::user()->invoiceNumberFormat($invoice->invoice_id);
            $invoiceId = Crypt::encrypt($invoice->id);
            $invoice->url = route('invoice.pdf', $invoiceId);

            $customerArr = [
                'customer_name' => $customer->name,
                'customer_email' => $customer->email,
                'invoice_name' => $customer->name,
                'invoice_number' => $invoice->invoice,
                'invoice_url' => $invoice->url,
            ];
            SalesPurchaseNotifier::customerInvoiceSent($customer, $customerArr);
        }
    }

    public function resent($id)
    {
        if (\Auth::user()->can('send invoice')) {
            $invoice = Invoice::where('id', $id)->first();

            $customer = Customer::where('id', $invoice->customer_id)->first();
            $invoice->name = !empty($customer) ? $customer->name : '';
            $invoice->invoice = \Auth::user()->invoiceNumberFormat($invoice->invoice_id);

            $invoiceId = Crypt::encrypt($invoice->id);
            $invoice->url = route('invoice.pdf', $invoiceId);
            $customerArr = [

                'customer_name' => $customer->name,
                'customer_email' => $customer->email,
                'invoice_name' => $customer->name,
                'invoice_number' => $invoice->invoice,
                'invoice_url' => $invoice->url,

            ];
            $resp = SalesPurchaseNotifier::customerInvoiceSent($customer, $customerArr);

            return redirect()->back()->with('success', __('Invoice successfully sent.') . (($resp !== null && ($resp['is_success'] ?? true) == false && !empty($resp['error'])) ? '<br> <span class="text-danger">' . $resp['error'] . '</span>' : ''));

        } else {
            return redirect()->back()->with('error', __('Permission denied.'));
        }
    }

    public function payment($invoice_id)
    {
        if (\Auth::user()->can('create payment invoice')) {
            $invoice = Invoice::where('id', $invoice_id)->first();

            $customers = Customer::where('created_by', '=', \Auth::user()->creatorId())->get()->pluck('name', 'id');
            $categories = ProductServiceCategory::where('created_by', '=', \Auth::user()->creatorId())->get()->pluck('name', 'id');
            $accounts = BankAccount::select('*', \DB::raw("CONCAT(bank_name,' ',holder_name) AS name"))->where('created_by', \Auth::user()->creatorId())->get()->pluck('name', 'id');

            return view('invoice.payment', compact('customers', 'categories', 'accounts', 'invoice'));
        } else {
            return redirect()->back()->with('error', __('Permission denied.'));
        }
    }

    public function createPayment(Request $request, $invoice_id)
    {
        $invoice = Invoice::find($invoice_id);
        if ($invoice->getDue() < $request->amount) {
            return redirect()->back()->with('error', __('Invoice payment amount should not greater than subtotal.'));
        }

        if (\Auth::user()->can('create payment invoice')) {
            $validator = \Validator::make(
                $request->all(), [
                    'date' => 'required',
                    'amount' => 'required',
                    'account_id' => 'required',
                ]
            );
            if ($validator->fails()) {
                $messages = $validator->getMessageBag();

                return redirect()->back()->with('error', $messages->first());
            }

            $invoicePayment = new InvoicePayment();
            $invoicePayment->invoice_id = $invoice_id;
            $invoicePayment->date = $request->date;
            $invoicePayment->amount = $request->amount;
            $invoicePayment->account_id = $request->account_id;
            $invoicePayment->payment_method = 0;
            $invoicePayment->reference = $request->reference;
            $invoicePayment->description = $request->description;
            if (!empty($request->add_receipt)) {
                //storage limit
                $image_size = $request->file('add_receipt')->getSize();
                $result = Utility::updateStorageLimit(\Auth::user()->creatorId(), $image_size);
                if ($result == 1) {
                    $fileName = time() . "_" . $request->add_receipt->getClientOriginalName();
                    $request->add_receipt->storeAs('uploads/payment', $fileName);
                    $invoicePayment->add_receipt = $fileName;
                }

            }

            $invoicePayment->save();

            $invoice = Invoice::where('id', $invoice_id)->first();
            $due = $invoice->getDue();
            $total = $invoice->getTotal();
            if ($invoice->status == 0) {
                $invoice->send_date = date('Y-m-d');
                $invoice->save();
            }

            if ($due <= 0) {
                $invoice->status = 4;
                $invoice->save();
            } else {
                $invoice->status = 3;
                $invoice->save();
            }
            $invoicePayment->user_id = $invoice->customer_id;
            $invoicePayment->user_type = 'Customer';
            $invoicePayment->type = 'Partial';
            $invoicePayment->created_by = \Auth::user()->id;
            $invoicePayment->payment_id = $invoicePayment->id;
            $invoicePayment->category = 'Invoice';
            $invoicePayment->account = $request->account_id;

            Transaction::addTransaction($invoicePayment);
            $customer = Customer::where('id', $invoice->customer_id)->first();

            $payment = new InvoicePayment();
            $payment->name = $customer['name'];
            $payment->date = \Auth::user()->dateFormat($request->date);
            $payment->amount = \Auth::user()->priceFormat($request->amount);
            $payment->invoice = 'invoice ' . \Auth::user()->invoiceNumberFormat($invoice->invoice_id);
            $payment->dueAmount = \Auth::user()->priceFormat($invoice->getDue());

            // Utility::updateUserBalance('customer', $invoice->customer_id, $request->amount, 'debit');
            Utility::updateUserBalance('customer', $invoice->customer_id, $request->amount, 'credit');

            Utility::bankAccountBalance($request->account_id, $request->amount, 'credit');

            $accountId = BankAccount::find($request->account_id);
            // Remove prior one-sided payment lines for this payment id, then post balanced pair.
            TransactionLines::where('reference_id', $invoice->id)
                ->where('reference_sub_id', $invoicePayment->id)
                ->whereIn('reference', ['Invoice Payment', 'Invoice Payment AR'])
                ->delete();

            app(DocumentLedgerService::class)->postInvoicePayment(
                (int) \Auth::user()->creatorId(),
                (int) $invoice->id,
                (int) $invoicePayment->id,
                (float) $request->amount,
                (string) $request->date,
                $accountId?->chart_account_id ? (int) $accountId->chart_account_id : null
            );

            $invoice_payment_method = InvoicePayment::where('invoice_id', $invoice->id)->orderBy('id', 'desc')->first();
            $invoicePaymentArr = [
                'invoice_payment_name' => $customer->name,
                'invoice_payment_amount' => $payment->amount,
                'invoice_payment_date' => $payment->date,
                'payment_dueAmount' => $payment->dueAmount,
                'invoice_number' => \Auth::user()->priceFormat($invoice->getDue()),
                'invoice_payment_method' => $invoice_payment_method->payment_type,
            ];
            $resp = SalesPurchaseNotifier::customerInvoicePayment($customer, $invoicePaymentArr);

            //webhook
            $module = 'New Invoice Payment';
            $webhook = Utility::webhookSetting($module);
            if ($webhook) {
                $parameter = json_encode($invoice);
                $status = Utility::WebhookCall($webhook['url'], $parameter, $webhook['method']);
                if ($status == true) {
                    return redirect()->back()->with('success', __('Payment successfully added.') . ((isset($result) && $result != 1) ? '<br> <span class="text-danger">' . $result . '</span>' : '') . (($resp !== null && ($resp['is_success'] ?? true) == false && !empty($resp['error'])) ? '<br> <span class="text-danger">' . $resp['error'] . '</span>' : ''));

                } else {
                    return redirect()->back()->with('error', __('Payment successfully, Webhook call failed.'));
                }
            }
            return redirect()->back()->with('success', __('Payment successfully added.') . ((isset($result) && $result != 1) ? '<br> <span class="text-danger">' . $result . '</span>' : '') . (($resp !== null && ($resp['is_success'] ?? true) == false && !empty($resp['error'])) ? '<br> <span class="text-danger">' . $resp['error'] . '</span>' : ''));

        }

    }

    public function paymentDestroy(Request $request, $invoice_id, $payment_id)
    {

        if (\Auth::user()->can('delete payment invoice')) {
            $payment = InvoicePayment::find($payment_id);

            InvoicePayment::where('id', '=', $payment_id)->delete();

            InvoiceBankTransfer::where('id', '=', $payment_id)->delete();

            TransactionLines::where('reference_sub_id',$payment_id)->where('reference','Invoice Payment')->delete();

            $invoice = Invoice::where('id', $invoice_id)->first();
            $due = $invoice->getDue();
            $total = $invoice->getTotal();

            if ($due > 0 && $total != $due) {
                $invoice->status = 3;

            } else {
                $invoice->status = 2;
            }

            if (!empty($payment->add_receipt)) {
                //storage limit
                $file_path = '/uploads/payment/' . $payment->add_receipt;
                $result = Utility::changeStorageLimit(\Auth::user()->creatorId(), $file_path);

            }

            $invoice->save();
            $type = 'Partial';
            $user = 'Customer';
            Transaction::destroyTransaction($payment_id, $type, $user);

            Utility::updateUserBalance('customer', $invoice->customer_id, $payment->amount, 'credit');

            Utility::bankAccountBalance($payment->account_id, $payment->amount, 'debit');

            return redirect()->back()->with('success', __('Payment successfully deleted.'));
        } else {
            return redirect()->back()->with('error', __('Permission denied.'));
        }
    }

    public function paymentReminder($invoice_id)
    {
        $invoice = Invoice::find($invoice_id);
        $customer = Customer::find($invoice->customer_id);
        $invoice->dueAmount = \Auth::user()->priceFormat($invoice->getDue());
        $invoice->name = $customer->name;
        $invoice->date = \Auth::user()->dateFormat($invoice->send_date);
        $invoice->invoice = \Auth::user()->invoiceNumberFormat($invoice->invoice_id);

        $reminderNotificationArr = [
            'invoice_number' => $invoice->invoice,
            'customer_name' => $customer->name,
            'user_name' => \Auth::user()->name,
        ];

        $reminderArr = [
            'payment_reminder_name' => $invoice->name,
            'invoice_payment_number' => $invoice->invoice,
            'invoice_payment_dueAmount' => $invoice->dueAmount,
            'payment_reminder_date' => $invoice->date,
        ];

        $resp = SalesPurchaseNotifier::customerPaymentReminder($customer, $reminderArr, $reminderNotificationArr);

        return redirect()->back()->with('success', __('Payment reminder successfully send.') . (($resp !== null && ($resp['is_success'] ?? true) == false && !empty($resp['error'])) ? '<br> <span class="text-danger">' . $resp['error'] . '</span>' : ''));
    }

    public function customerInvoiceSend($invoice_id)
    {
        return view('customer.invoice_send', compact('invoice_id'));
    }

    public function customerInvoiceSendMail(Request $request, $invoice_id)
    {
        $validator = \Validator::make(
            $request->all(), [
                'email' => 'required|email',
            ]
        );
        if ($validator->fails()) {
            $messages = $validator->getMessageBag();

            return redirect()->back()->with('error', $messages->first());
        }

        $email = $request->email;
        $invoice = Invoice::where('id', $invoice_id)->first();

        $customer = Customer::where('id', $invoice->customer_id)->first();
        $invoice->name = !empty($customer) ? $customer->name : '';
        $invoice->invoice = \Auth::user()->invoiceNumberFormat($invoice->invoice_id);

        $invoiceId = Crypt::encrypt($invoice->id);
        $invoice->url = route('invoice.pdf', $invoiceId);

        try
        {
            LoggedMail::send($email, new CustomerInvoiceSend($invoice), [
                'source' => 'customer_invoice',
                'subject' => __('Invoice') . ' ' . ($invoice->invoice ?? ''),
            ]);
        } catch (\Exception $e) {
            $smtp_error = __('E-Mail has been not sent due to SMTP configuration');
        }

        return redirect()->back()->with('success', __('Invoice successfully sent.') . ((isset($smtp_error)) ? '<br> <span class="text-danger">' . $smtp_error . '</span>' : ''));

    }

    public function shippingDisplay(Request $request, $id)
    {
        $invoice = Invoice::find($id);

        if ($request->is_display == 'true') {
            $invoice->shipping_display = 1;
        } else {
            $invoice->shipping_display = 0;
        }
        $invoice->save();

        return redirect()->back()->with('success', __('Shipping address status successfully changed.'));
    }

    public function duplicate($invoice_id)
    {
        if (\Auth::user()->can('duplicate invoice')) {
            $invoice = Invoice::where('id', $invoice_id)->first();
            $duplicateInvoice = new Invoice();
            $duplicateInvoice->invoice_id = $this->invoiceNumber();
            $duplicateInvoice->customer_id = $invoice['customer_id'];
            $duplicateInvoice->issue_date = date('Y-m-d');
            $duplicateInvoice->due_date = $invoice['due_date'];
            $duplicateInvoice->send_date = null;
            $duplicateInvoice->category_id = $invoice['category_id'];
            $duplicateInvoice->ref_number = $invoice['ref_number'];
            $duplicateInvoice->status = 0;
            $duplicateInvoice->shipping_display = $invoice['shipping_display'];
            $duplicateInvoice->created_by = $invoice['created_by'];
            $duplicateInvoice->save();

            if ($duplicateInvoice) {
                $invoiceProduct = InvoiceProduct::where('invoice_id', $invoice_id)->get();
                foreach ($invoiceProduct as $product) {
                    $duplicateProduct = new InvoiceProduct();
                    $duplicateProduct->invoice_id = $duplicateInvoice->id;
                    $duplicateProduct->product_id = $product->product_id;
                    $duplicateProduct->quantity = $product->quantity;
                    $duplicateProduct->tax = $product->tax;
                    $duplicateProduct->discount = $product->discount;
                    $duplicateProduct->price = $product->price;
                    $duplicateProduct->description = $product->description;
                    $duplicateProduct->identifiers = $product->identifiers;
                    $duplicateProduct->save();
                }
            }

            return redirect()->back()->with('success', __('Invoice duplicate successfully.'));
        } else {
            return redirect()->back()->with('error', __('Permission denied.'));
        }
    }

    public function previewInvoice($template, $color)
    {

        $objUser = \Auth::user();
        $settings = Utility::settings();
        $invoice = new Invoice();

        $customer = new \stdClass();
        $customer->email = '<Email>';
        $customer->shipping_name = '<Customer Name>';
        $customer->shipping_country = '<Country>';
        $customer->shipping_state = '<State>';
        $customer->shipping_city = '<City>';
        $customer->shipping_phone = '<Customer Phone Number>';
        $customer->shipping_zip = '<Zip>';
        $customer->shipping_address = '<Address>';
        $customer->billing_name = '<Customer Name>';
        $customer->billing_country = '<Country>';
        $customer->billing_state = '<State>';
        $customer->billing_city = '<City>';
        $customer->billing_phone = '<Customer Phone Number>';
        $customer->billing_zip = '<Zip>';
        $customer->billing_address = '<Address>';

        $totalTaxPrice = 0;
        $taxesData = [];

        $items = [];
        for ($i = 1; $i <= 3; $i++) {
            $item = new \stdClass();
            $item->name = 'Item ' . $i;
            $item->quantity = 1;
            $item->tax = 5;
            $item->discount = 50;
            $item->price = 100;
            $item->unit = 1;
            $item->description = 'XYZ';

            $taxes = [
                'Tax 1',
                'Tax 2',
            ];

            $itemTaxes = [];
            foreach ($taxes as $k => $tax) {
                $taxPrice = 10;
                $totalTaxPrice += $taxPrice;
                $itemTax['name'] = 'Tax ' . $k;
                $itemTax['rate'] = '10 %';
                $itemTax['price'] = '$10';
                $itemTax['tax_price'] = 10;
                $itemTaxes[] = $itemTax;
                if (array_key_exists('Tax ' . $k, $taxesData)) {
                    $taxesData['Tax ' . $k] = $taxesData['Tax 1'] + $taxPrice;
                } else {
                    $taxesData['Tax ' . $k] = $taxPrice;
                }
            }
            $item->itemTax = $itemTaxes;
            $items[] = $item;
        }

        $invoice->invoice_id = 1;
        $invoice->issue_date = date('Y-m-d H:i:s');
        $invoice->due_date = date('Y-m-d H:i:s');
        $invoice->itemData = $items;
        $invoice->status = 0;
        $invoice->totalTaxPrice = 60;
        $invoice->totalQuantity = 3;
        $invoice->totalRate = 300;
        $invoice->totalDiscount = 10;
        $invoice->taxesData = $taxesData;
        $invoice->created_by = $objUser->creatorId();

        $invoice->customField = [];
        $customFields = [];

        $preview = 1;
        $color = '#' . $color;
        $font_color = Utility::getFontColor($color);

        $logo = asset(Storage::url('uploads/logo/'));
        $company_logo = Utility::getValByName('company_logo_dark');
        $invoice_logo = Utility::getValByName('invoice_logo');
        if (isset($invoice_logo) && !empty($invoice_logo)) {
            $img = Utility::get_file('invoice_logo/') . $invoice_logo;
        } else {
            $img = asset($logo . '/' . (isset($company_logo) && !empty($company_logo) ? $company_logo : 'logo-dark.png'));
        }

        return view('invoice.templates.' . $template, compact('invoice', 'preview', 'color', 'img', 'settings', 'customer', 'font_color', 'customFields'));
    }

    public function invoice($invoice_id)
    {
        $settings = Utility::settings();

        try{
            $invoiceId = Crypt::decrypt($invoice_id);
        } catch (\Exception $e){
            return redirect()->back()->with('error', __('Something went wrong.'));
        }

        $invoice = Invoice::with(['pos.branch', 'pos.table', 'pos.shift', 'billing_address', 'shipping_address', 'sourcePurchase', 'sourceQuotation', 'sourceProforma'])->where('id', $invoiceId)->first();

        $data = DB::table('settings');
        $data = $data->where('created_by', '=', $invoice->created_by);
        $data1 = $data->get();

        foreach ($data1 as $row) {
            $settings[$row->name] = $row->value;
        }

        $customer = $invoice->customer;
        $items = [];
        $totalTaxPrice = 0;
        $totalQuantity = 0;
        $totalRate = 0;
        $totalDiscount = 0;
        $taxesData = [];
        foreach ($invoice->items as $product) {
            $item = new \stdClass();
            $item->name = !empty($product->product) ? $product->product->name : '';
            $item->quantity = $product->quantity;
            $item->tax = $product->tax;
            $item->unit = !empty($product->product) ? $product->product->unit_id : '';
            $item->discount = $product->discount;
            $item->price = $product->price;
            $item->description = $product->description;
            $item->identifiers = $product->identifiers;

            $totalQuantity += $item->quantity;
            $totalRate += $item->price;
            $totalDiscount += $item->discount;

            $taxes = Utility::tax($product->tax);

            $itemTaxes = [];
            if (!empty($item->tax)) {
                foreach ($taxes as $tax) {
                    $taxPrice = Utility::taxRate($tax->rate, $item->price, $item->quantity, $item->discount);
                    $totalTaxPrice += $taxPrice;

                    $itemTax['name'] = $tax->name;
                    $itemTax['rate'] = $tax->rate ?? 0 . '%';
                    $itemTax['price'] = Utility::priceFormat($settings, $taxPrice);
                    $itemTax['tax_price'] = $taxPrice;
                    $itemTaxes[] = $itemTax;

                    if (array_key_exists($tax->name, $taxesData)) {
                        $taxesData[$tax->name] = $taxesData[$tax->name] + $taxPrice;
                    } else {
                        $taxesData[$tax->name] = $taxPrice;
                    }

                }
                $item->itemTax = $itemTaxes;
            } else {
                $item->itemTax = [];
            }
            $items[] = $item;
        }

        $invoice->itemData = $items;
        $invoice->totalTaxPrice = $totalTaxPrice;
        $invoice->totalQuantity = $totalQuantity;
        $invoice->totalRate = $totalRate;
        $invoice->totalDiscount = $totalDiscount;
        $invoice->taxesData = $taxesData;
        $invoice->customField = CustomField::getData($invoice, 'invoice');
        $customFields = [];
        if (!empty(\Auth::user())) {
            $customFields = CustomField::where('created_by', '=', \Auth::user()->creatorId())->where('module', '=', 'invoice')->get();
        }

        $logo = asset(Storage::url('uploads/logo/'));
        $company_logo = Utility::getValByName('company_logo_dark');
        $settings_data = \App\Models\Utility::settingsById($invoice->created_by);
        $invoice_logo = $settings_data['invoice_logo'];
        if (isset($invoice_logo) && !empty($invoice_logo)) {
            $img = Utility::get_file('invoice_logo/') . $invoice_logo;
        } else {
            $img = asset($logo . '/' . (isset($company_logo) && !empty($company_logo) ? $company_logo : 'logo-dark.png'));
        }

        if ($invoice) {
            $color = '#' . $settings['invoice_color'];
            $font_color = Utility::getFontColor($color);

            return view('invoice.templates.' . $settings['invoice_template'], compact('invoice', 'color', 'settings', 'customer', 'img', 'font_color', 'customFields'));
        } else {
            return redirect()->back()->with('error', __('Permission denied.'));
        }

    }

    public function saveTemplateSettings(Request $request)
    {

        $post = $request->all();
        unset($post['_token']);

        if (isset($post['invoice_template']) && (!isset($post['invoice_color']) || empty($post['invoice_color']))) {
            $post['invoice_color'] = "ffffff";
        }

        if ($request->invoice_logo) {
            $dir = 'invoice_logo/';
            $invoice_logo = \Auth::user()->id . '_invoice_logo.png';
            $validation = [
                'mimes:' . 'png',
                'max:' . '20480',
            ];
            $path = Utility::upload_file($request, 'invoice_logo', $invoice_logo, $dir, $validation);

            if ($path['flag'] == 0) {
                return redirect()->back()->with('error', __($path['msg']));
            }
            $post['invoice_logo'] = $invoice_logo;
        }

        foreach ($post as $key => $data) {
            \DB::insert(
                'insert into settings (`value`, `name`,`created_by`) values (?, ?, ?) ON DUPLICATE KEY UPDATE `value` = VALUES(`value`) ', [
                    $data,
                    $key,
                    \Auth::user()->creatorId(),
                ]
            );
        }

        return redirect()->back()->with('success', __('Invoice Setting updated successfully'));
    }

    public function items(Request $request)
    {
        $items = InvoiceProduct::where('invoice_id', $request->invoice_id)->where('product_id', $request->product_id)->first();

        return json_encode($items);
    }

    public function invoiceLink($invoiceId)
    {
        try {
            $id = Crypt::decrypt($invoiceId);
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', __('Invoice Not Found.'));
        }

        $id = Crypt::decrypt($invoiceId);
        $invoice = Invoice::with(['creditNote','payments.bankAccount','items.product.unit'])->find($id);
        $settings = Utility::settingsById($invoice->created_by);

        if (!empty($invoice)) {

            $user_id = $invoice->created_by;
            $user = User::find($user_id);
            $invoicePayment = InvoicePayment::where('invoice_id', $invoice->id)->get();
            $customer = $invoice->customer;
            $iteams = $invoice->items;
            $invoice->customField = CustomField::getData($invoice, 'invoice');
            $customFields = CustomField::where('module', '=', 'invoice')->where('created_by', $invoice->created_by)->get();
            $company_payment_setting = Utility::getCompanyPaymentSetting($user_id);

            // start for storage limit note
            $user_plan = Plan::find($user->plan);
            // end for storage limit note

            return view('invoice.customer_invoice', compact('settings', 'invoice', 'customer', 'iteams', 'invoicePayment', 'customFields', 'user', 'company_payment_setting', 'user_plan'));
        } else {
            return redirect()->back()->with('error', __('Permission Denied.'));
        }

    }

    public function export()
    {
        $name = 'invoice_' . date('Y-m-d i:h:s');
        $data = Excel::download(new InvoiceExport(), $name . '.xlsx');
        ob_end_clean();

        return $data;
    }
    
    public function exportInvoiceNotes(Request $request)
    {
        $data= null;
        if($request->type == 1)
        {
            $name = 'invoice_credit_notes_' . date('Y-m-d i:h:s');
            $data = Excel::download(new InvoiceCreditNotesExport(), $name . '.xlsx');
        }
        else{
            $name = 'invoice_debit_notes_' . date('Y-m-d i:h:s');
            $data = Excel::download(new InvoiceDebitNotesExport(), $name . '.xlsx');
        }
        ob_end_clean();

        return $data;
    }

}