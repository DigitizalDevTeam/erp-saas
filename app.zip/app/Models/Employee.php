<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $fillable = [
        'user_id',
        'name',
        'dob',
        'gender',
        'phone',
        'address',
        'email',
        'password',
        'employee_id',
        'branch_id',
        'department_id',
        'designation_id',
        'company_doj',
        'documents',
        'account_holder_name',
        'account_number',
        'bank_name',
        'bank_identifier_code',
        'branch_location',
        'tax_payer_id',
        'dependents',
        'inss_employer_pays_all',
        'salary_type',
        'biometric_emp_id',
        'account',
        'salary_chart_account_id',
        'salary',
        'attendance_use_company_default',
        'work_schedule_type',
        'work_start_time',
        'work_end_time',
        'grace_minutes',
        'created_by',
    ];

    protected $casts = [
        'attendance_use_company_default' => 'boolean',
        'grace_minutes' => 'integer',
    ];

    public function documents()
    {
        return $this->hasMany('App\Models\EmployeeDocument', 'employee_id', 'employee_id')->get();
    }

    public function salary_type()
    {
        return $this->hasOne('App\Models\PayslipType', 'id', 'salary_type')->pluck('name')->first();
    }

    public function allowances()
    {
        return $this->hasMany(Allowance::class);
    }

    public function commissions()
    {
        return $this->hasMany(Commission::class);
    }

    public function loans()
    {
        return $this->hasMany(Loan::class);
    }

    public function saturationDeductions()
    {
        return $this->hasMany(SaturationDeduction::class);
    }

    public function otherPayments()
    {
        return $this->hasMany(OtherPayment::class);
    }

    public function overtimes()
    {
        return $this->hasMany(Overtime::class);
    }

    /**
     * @param  string|null  $forPayrollMonthYm  When set, installment loans use first deduction month vs this payroll month.
     */
    public function get_net_salary(?string $forPayrollMonthYm = null)
    {
        $totals = $this->get_payroll_component_totals($forPayrollMonthYm);

        return $this->salary
            + $totals['allowance']
            + $totals['commission']
            - $totals['loan']
            - $totals['saturation_deduction']
            + $totals['other_payment']
            + $totals['overtime'];
    }

    /**
     * Earnings base used for IRPS before non-statutory deductions are applied.
     *
     * @param  string|null  $forPayrollMonthYm
     */
    public function get_irps_base_salary(?string $forPayrollMonthYm = null)
    {
        $totals = $this->get_payroll_component_totals($forPayrollMonthYm);

        return $this->salary
            + $totals['allowance']
            + $totals['commission']
            + $totals['other_payment']
            + $totals['overtime'];
    }

    /**
     * @return array{
     *     allowance: float,
     *     commission: float,
     *     loan: float,
     *     saturation_deduction: float,
     *     other_payment: float,
     *     overtime: float
     * }
     */
    private function get_payroll_component_totals(?string $forPayrollMonthYm = null): array
    {
        $monthYm = $forPayrollMonthYm ?? date('Y-m');

        return [
            'allowance' => $this->allowances->sum(function ($allowance) {
                return ($allowance->type === 'fixed') ? $allowance->amount : ($allowance->amount * $this->salary / 100);
            }),
            'commission' => $this->commissions->sum(function ($commission) {
                return ($commission->type === 'fixed') ? $commission->amount : ($commission->amount * $this->salary / 100);
            }),
            'loan' => $this->loans->sum(function ($loan) use ($monthYm) {
                return $loan->estimatedMonthlyPayrollImpact((float) $this->salary, $monthYm);
            }),
            'saturation_deduction' => $this->saturationDeductions->sum(function ($deduction) {
                return ($deduction->type === 'fixed') ? $deduction->amount : ($deduction->amount * $this->salary / 100);
            }),
            'other_payment' => $this->otherPayments->sum(function ($otherPayment) {
                return ($otherPayment->type === 'fixed') ? $otherPayment->amount : ($otherPayment->amount * $this->salary / 100);
            }),
            'overtime' => $this->overtimes->sum(function ($over_time) {
                return $over_time->number_of_days * $over_time->hours * $over_time->rate;
            }),
        ];
    }


    public static function allowance($id)
    {

        //allowance
        $allowances      = Allowance::where('employee_id', '=', $id)->get();
        $total_allowance = 0;
        foreach($allowances as $allowance)
        {
            $total_allowance = $allowance->amount + $total_allowance;
        }

        $allowance_json = json_encode($allowances);

        return $allowance_json;

    }

    public static function commission($id)
    {
        //commission
        $commissions      = Commission::where('employee_id', '=', $id)->get();
        $total_commission = 0;
        foreach($commissions as $commission)
        {
            $total_commission = $commission->amount + $total_commission;
        }
        $commission_json = json_encode($commissions);

        return $commission_json;

    }

    /**
     * JSON snapshot of loan rows for a payslip month (legacy % / fixed + installment EMI).
     */
    public static function loanJsonForPayslipMonth(int $employeeId, string $salaryMonthYm, float $basicSalary): string
    {
        $loans = Loan::where('employee_id', '=', $employeeId)->orderBy('id')->get();
        $rows = [];
        foreach ($loans as $loan) {
            $rows[] = $loan->toPayslipSnapshotObject($salaryMonthYm, $basicSalary);
        }

        return json_encode($rows);
    }

    /**
     * @deprecated Use loanJsonForPayslipMonth with an explicit payroll month.
     */
    public static function loan($id)
    {
        return self::loanJsonForPayslipMonth($id, date('Y-m'), 0);
    }

    public static function saturation_deduction($id)
    {
        //Saturation Deduction
        $saturation_deductions      = SaturationDeduction::where('employee_id', '=', $id)->get();
        $total_saturation_deduction = 0;
        foreach($saturation_deductions as $saturation_deduction)
        {
            $total_saturation_deduction = $saturation_deduction->amount + $total_saturation_deduction;
        }
        $saturation_deduction_json = json_encode($saturation_deductions);

        return $saturation_deduction_json;

    }

    public static function other_payment($id)
    {
        //OtherPayment
        $other_payments      = OtherPayment::where('employee_id', '=', $id)->get();
        $total_other_payment = 0;
        foreach($other_payments as $other_payment)
        {
            $total_other_payment = $other_payment->amount + $total_other_payment;
        }
        $other_payment_json = json_encode($other_payments);

        return $other_payment_json;
    }

    public static function overtime($id)
    {
        //Overtime
        $over_times      = Overtime::where('employee_id', '=', $id)->get();
        $total_over_time = 0;
        foreach($over_times as $over_time)
        {
            $total_work      = $over_time->number_of_days * $over_time->hours;
            $amount          = $total_work * $over_time->rate;
            $total_over_time = $amount + $total_over_time;
        }
        $over_time_json = json_encode($over_times);

        return $over_time_json;
    }

    public static function employee_id()
    {
        $employee = Employee::latest()->first();

        return !empty($employee) ? $employee->id + 1 : 1;
    }

    public function branch()
    {
        return $this->hasOne('App\Models\Branch', 'id', 'branch_id');
    }

    public function department()
    {
        return $this->hasOne('App\Models\Department', 'id', 'department_id');
    }

    public function designation()
    {
        return $this->hasOne('App\Models\Designation', 'id', 'designation_id');
    }

    public function salaryType()
    {
        return $this->hasOne('App\Models\PayslipType', 'id', 'salary_type');
    }

    public function user()
    {
        return $this->hasOne('App\Models\User', 'id', 'user_id');
    }

    public function paySlip()
    {
        return $this->hasOne('App\Models\PaySlip', 'id', 'employee_id');
    }

    public function bankAccount()
    {
        return $this->hasOne('App\Models\BankAccount', 'id', 'account');
    }


    public function present_status($employee_id, $data)
    {
        return AttendanceEmployee::where('employee_id', $employee_id)->where('date', $data)->first();
    }


    public static function employee_salary($salary)
    {
        $employee = Employee::where("salary", $salary)->first();
        if ($employee->salary == '0' || $employee->salary == '0.0') {
            return "-";
        } else {
            return $employee->salary;
        }
    }





}
