@extends('layouts.admin')

@section('page-title')
    {{__('Employee')}}
@endsection
@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{route('dashboard')}}">{{__('Dashboard')}}</a></li>
    <li class="breadcrumb-item"><a href="{{route('employee.index')}}">{{__('Employee')}}</a></li>
    <li class="breadcrumb-item">{{$employeesId}}</li>
@endsection

@section('action-btn')
    @if(!empty($employee))
        <div class="text-end">
            <div class="d-flex flex-wrap align-items-center justify-content-md-end gap-2">
                <a href="{{ route('joiningletter.download.pdf', $employee->id) }}"
                   class="btn btn-sm btn-outline-primary" target="_blank" rel="noopener"
                   data-bs-toggle="tooltip" title="{{ __('Joining Letter PDF') }}">
                    <i class="ti ti-file-type-pdf"></i> {{ __('Joining Letter') }}
                </a>
                <a href="{{ route('exp.download.pdf', $employee->id) }}"
                   class="btn btn-sm btn-outline-primary" target="_blank" rel="noopener"
                   data-bs-toggle="tooltip" title="{{ __('Experience Certificate PDF') }}">
                    <i class="ti ti-file-type-pdf"></i> {{ __('Experience Certificate') }}
                </a>
                <a href="{{ route('noc.download.pdf', $employee->id) }}"
                   class="btn btn-sm btn-outline-primary" target="_blank" rel="noopener"
                   data-bs-toggle="tooltip" title="{{ __('NOC PDF') }}">
                    <i class="ti ti-file-type-pdf"></i> {{ __('NOC') }}
                </a>
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                        {{ __('DOC') }}
                    </button>
                    <div class="dropdown-menu dropdown-menu-end">
                        <a href="{{ route('joininglatter.download.doc', $employee->id) }}" class="dropdown-item" target="_blank" rel="noopener">
                            <i class="ti ti-file-text me-1"></i>{{ __('Joining Letter') }}
                        </a>
                        <a href="{{ route('exp.download.doc', $employee->id) }}" class="dropdown-item" target="_blank" rel="noopener">
                            <i class="ti ti-file-text me-1"></i>{{ __('Experience Certificate') }}
                        </a>
                        <a href="{{ route('noc.download.doc', $employee->id) }}" class="dropdown-item" target="_blank" rel="noopener">
                            <i class="ti ti-file-text me-1"></i>{{ __('NOC') }}
                        </a>
                    </div>
                </div>
                @can('manage report')
                    <a href="{{ route('monthly.reports.irps-modelo-19', ['month' => now()->format('Y-m'), 'download' => 'pdf']) }}"
                        data-bs-toggle="tooltip" title="{{ __('IRPS Modelo 19 (PDF)') }}" class="btn btn-sm btn-primary"
                        target="_blank" rel="noopener">
                        <i class="ti ti-report-money"></i>
                    </a>
                @endcan
                @can('edit employee')
                    <a href="{{ route('employee.edit', \Illuminate\Support\Facades\Crypt::encrypt($employee->id)) }}"
                       data-bs-toggle="tooltip" title="{{ __('Edit') }}" class="btn btn-sm btn-info">
                        <i class="ti ti-pencil"></i>
                    </a>
                @endcan
            </div>
        </div>
    @endif
@endsection

@section('content')
    @if(!empty($employee))
    <div class="row gy-4">
        <div class="col-md-6 col-12">
            <div class="card h-100 mb-0">
                <div class="card-header">
                    <h5>{{ __('Personal Detail') }}</h5>
                </div>
                <div class="card-body employee-detail-body">
                    
                    <div class="row gy-2">
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('EmployeeId') }} : </strong>
                                <span>{{ $employeesId }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info font-style">
                                <strong class="font-bold">{{ __('Name') }} :</strong>
                                <span>{{ !empty($employee) ? $employee->name : '' }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info font-style">
                                <strong class="font-bold">{{ __('Email') }} :</strong>
                                <span>{{ !empty($employee) ? $employee->email : '' }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Date of Birth') }} :</strong>
                                <span>{{ \Auth::user()->dateFormat(!empty($employee) ? $employee->dob : '') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Phone') }} :</strong>
                                <span>{{ !empty($employee) ? $employee->phone : '' }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Address') }} :</strong>
                                <span>{{ !empty($employee) ? $employee->address : '' }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Salary Type') }} :</strong>
                                <span>{{ !empty($employee->salaryType) ? $employee->salaryType->name : '' }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Basic Salary') }} :</strong>
                                <span>{{ !empty($employee) ? $employee->salary : '' }}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-12">
            <div class="card h-100 mb-0">
                <div class="card-header">
                    <h5>{{ __('Company Detail') }}</h5>
                </div>
                <div class="card-body employee-detail-body">
                    
                    <div class="row gy-2">
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Branch') }} : </strong>
                                <span>{{ !empty($employee->branch) ? $employee->branch->name : '' }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Department') }} :</strong>
                                <span>{{ !empty($employee->department) ? $employee->department->name : '' }}</span>
                            </div>
                        </div>

                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Designation') }} :</strong>
                                <span>{{ !empty($employee->designation) ? $employee->designation->name : '' }}</span>
                            </div>
                        </div>

                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Date Of Joining') }} :</strong>
                                <span>{{ \Auth::user()->dateFormat(!empty($employee) ? $employee->company_doj : '') }}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-12">
            <div class="card h-100 mb-0">
                <div class="card-header">
                    <h5>{{ __('Document Detail') }}</h5>
                </div>
                <div class="card-body employee-detail-body">
                    
                    <div class="row gy-2">
                        @php

                            $employeedoc = !empty($employee)
                                ? $employee->documents()->pluck('document_value', __('document_id'))
                                : [];
                        @endphp
                        @if (!$documents->isEmpty())
                            @foreach ($documents as $key => $document)
                                <div class="col-sm-6 col-12">
                                    <div class="info">
                                        <strong class="font-bold">{{ $document->name }} : </strong>
                                        <span><a href="{{ !empty($employeedoc[$document->id]) ? asset(Storage::url('uploads/document')) . '/' . $employeedoc[$document->id] : '' }}"
                                                target="_blank">{{ !empty($employeedoc[$document->id]) ? $employeedoc[$document->id] : '' }}</a></span>
                                    </div>
                                </div>
                            @endforeach
                        @else
                            <div class="text-center">
                                No Document Type Added.!
                            </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-12">
            <div class="card h-100 mb-0">
                <div class="card-header">
                    <h5>{{ __('Bank Account Detail') }}</h5>
                </div>
                <div class="card-body employee-detail-body">
                    
                    <div class="row gy-2">
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Account Holder Name') }} : </strong>
                                <span>{{ !empty($employee) ? $employee->account_holder_name : '' }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Account Number') }} :</strong>
                                <span>{{ !empty($employee) ? $employee->account_number : '' }}</span>
                            </div>
                        </div>

                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Bank Name') }} :</strong>
                                <span>{{ !empty($employee) ? $employee->bank_name : '' }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Bank Identifier Code') }} :</strong>
                                <span>{{ !empty($employee) ? $employee->bank_identifier_code : '' }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Branch Location') }} :</strong>
                                <span>{{ !empty($employee) ? $employee->branch_location : '' }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Tax Payer Id') }} :</strong>
                                <span>{{ !empty($employee) ? $employee->tax_payer_id : '' }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-12">
                            <div class="info">
                                <strong class="font-bold">{{ __('Number of Dependents') }} :</strong>
                                <span>{{ !empty($employee) ? (int) ($employee->dependents ?? 0) : 0 }}</span>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
        </div>
    @endif
@endsection
