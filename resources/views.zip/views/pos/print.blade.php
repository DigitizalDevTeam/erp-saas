@extends('layouts.admin')
@section('page-title')
    {{ __('pos.pos_barcode_print') }}
@endsection
@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{route('dashboard')}}">{{ __('pos.dashboard') }}</a></li>
    <li class="breadcrumb-item"><a href="{{route('pos.barcode')}}">{{ __('pos.pos_product_barcode') }}</a></li>
    <li class="breadcrumb-item">{{ __('pos.pos_barcode_print') }}</li>
@endsection
@push('css-page')
    <link rel="stylesheet" href="{{ asset('css/datatable/buttons.dataTables.min.css') }}">
@endpush

@push('script-page')
    <script type="text/javascript" src="{{ asset('js/html2pdf.bundle.min.js') }}"></script>
    <script>

        $(document).ready(function () {
            var b_id = $('#warehouse_id').val();
            getProduct(b_id);
        });
        $(document).on('change', 'select[name=warehouse_id]', function () {

            var warehouse_id = $(this).val();
            getProduct(warehouse_id);
        });

        function getProduct(bid) {

            $.ajax({
                url: '{{route('pos.getproduct')}}',
                type: 'POST',
                data: {
                    "warehouse_id": bid, "_token": "{{ csrf_token() }}",
                },

                success: function (data) {
                    $('#product_id').empty();

                    $("#product_div").html('');
                    $('#product_div').append('<label for="product_id" class="form-label">{{ __("pos.product") }}</label><span class="text-danger">*</span>');
                    $('#product_div').append(`<select class="form-label" id="product_id" name="product_id[]"  multiple required></select><div class="text-xs mt-1">
                                        {{ __('pos.create_product_here') }} <a href="{{ route('productservice.index') }}"><b>{{ __('pos.create_product') }}</b></a>
                                    </div>`);
                    $('#product_id').append('<option value="">{{ __("pos.select_product") }}</option>');

                    $.each(data, function (key, value) {
                        $('#product_id').append('<option value="' + key + '">' + value + '</option>');
                    });
                    var multipleCancelButton = new Choices('#product_id', {
                        removeItemButton: true,
                    });

                }

            });
        }


    </script>
    <script>
        function copyToClipboard(element) {
            var copyText = element.id;
            navigator.clipboard.writeText(copyText);
            // document.addEventListener('copy', function (e) {
            //     e.clipboardData.setData('text/plain', copyText);
            //     e.preventDefault();
            // }, true);
            // document.execCommand('copy');
            show_toastr('success', 'Url copied to clipboard', 'success');
        }
    </script>
    <script>
        var filename = $('#filesname').val();

        function saveAsPDF() {
            var element = document.getElementById('printableArea');
            var opt = {
                margin: 0.3,
                filename: filename,
                image: {type: 'jpeg', quality: 1},
                html2canvas: {scale: 4, dpi: 72, letterRendering: true},
                jsPDF: {unit: 'in', format: 'A2'}
            };
            html2pdf().set(opt).from(element).save();

        }
    </script>
@endpush


@section('action-btn')
    <div class="float-end">
        <a href="{{ route('pos.barcode') }}" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="{{__('Back')}}">
            <i class="ti ti-arrow-left text-white"></i>
        </a>
    </div>
@endsection


@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    {{Form::open(array('route'=>'pos.receipt','method'=>'post', 'class'=>'needs-validation', 'novalidate'))}}
                        <div class="row" id="printableArea">
                            <div class="col-md-4">
                                <div class="form-group">
                                    {{ Form::label('warehouse_id', __('pos.warehouse'), ['class'=>'form-label']) }}<x-required></x-required>
                                    {{ Form::select('warehouse_id', $warehouses,'', array('class' => 'form-control select','id'=>'warehouse_id','required'=>'required')) }}
                                    <div class="text-xs mt-1">
                                        {{ __('Create warehouse here.') }} <a href="{{ route('warehouse.index') }}"><b>{{ __('Create warehouse') }}</b></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group" id="product_div">
                                    {{ Form::label('product_id', __('pos.product'), ['class'=>'form-label']) }}<x-required></x-required>
                                    <select class="form-control select" name="product_id[]" id="product_id" required >
                                    </select>
                                    <div class="text-xs mt-1">
                                        {{ __('Create product here.') }} <a href="{{ route('productservice.index') }}"><b>{{ __('Create product') }}</b></a>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                {{ Form::label('quantity', __('Quantity'),['class'=>'form-label']) }}<x-required></x-required>
                                {{ Form::text('quantity',null, array('class' => 'form-control','required'=>'required', 'placeholder'=>__('Enter Quantity'))) }}
                            </div>
                        </div>
                        <div class="col-md-6 pt-4">
                            <button class="btn btn-sm btn-primary btn-icon" type="submit">{{__('Print')}}</button>
                        </div>
                    {{Form::close()}}
                </div>
            </div>
        </div>
    </div>
@endsection


