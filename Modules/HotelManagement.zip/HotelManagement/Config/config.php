<?php

return [
    'name' => 'HotelManagement',
];
